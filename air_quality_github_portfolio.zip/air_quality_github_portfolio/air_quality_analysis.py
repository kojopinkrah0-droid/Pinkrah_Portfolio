"""
Air Quality & Health Impact Analysis
Portfolio project: Python + Power BI
"""

from pathlib import Path
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt

DATA_PATH = Path("data/air_quality_health_dataset.csv")
OUTPUT_DIR = Path("outputs")
OUTPUT_DIR.mkdir(exist_ok=True)

def load_and_prepare(path=DATA_PATH):
    df = pd.read_csv(path)
    df["date"] = pd.to_datetime(df["date"])

    # Feature engineering
    df["year"] = df["date"].dt.year
    df["month_num"] = df["date"].dt.month
    df["month"] = df["date"].dt.month_name().str[:3]
    df["year_month"] = df["date"].dt.to_period("M").astype(str)
    df["capacity_utilization_pct"] = (
        df["hospital_admissions"] / df["hospital_capacity"] * 100
    ).round(2)

    def aqi_category(aqi):
        if aqi <= 50:
            return "Good"
        if aqi <= 100:
            return "Moderate"
        if aqi <= 150:
            return "Unhealthy for Sensitive Groups"
        if aqi <= 200:
            return "Unhealthy"
        if aqi <= 300:
            return "Very Unhealthy"
        return "Hazardous"

    df["aqi_category"] = df["aqi"].apply(aqi_category)
    return df

def quality_report(df):
    print("Shape:", df.shape)
    print("\nMissing values:\n", df.isna().sum())
    print("\nDuplicate rows:", df.duplicated().sum())
    print("\nDate range:", df["date"].min(), "to", df["date"].max())
    print("\nCities:", df["city"].nunique())

def create_summaries(df):
    city_summary = (
        df.groupby("city")
          .agg(
              avg_aqi=("aqi","mean"),
              avg_pm2_5=("pm2_5","mean"),
              avg_pm10=("pm10","mean"),
              avg_hospital_admissions=("hospital_admissions","mean"),
              total_hospital_admissions=("hospital_admissions","sum"),
              avg_capacity_utilization_pct=("capacity_utilization_pct","mean")
          )
          .sort_values("avg_aqi", ascending=False)
          .round(2)
    )
    city_summary.to_csv(OUTPUT_DIR / "city_summary.csv")

    corr_cols = [
        "aqi","pm2_5","pm10","no2","o3","temperature","humidity",
        "hospital_admissions","hospital_capacity","capacity_utilization_pct"
    ]
    df[corr_cols].corr().round(4).to_csv(OUTPUT_DIR / "correlation_matrix.csv")
    return city_summary

def create_charts(df, city_summary):
    plt.figure(figsize=(10,6))
    city_summary.sort_values("avg_aqi")["avg_aqi"].plot(kind="barh")
    plt.title("Average AQI by City")
    plt.xlabel("Average AQI")
    plt.tight_layout()
    plt.savefig(OUTPUT_DIR / "average_aqi_by_city.png", dpi=160)
    plt.close()

    sample = df.sample(min(6000, len(df)), random_state=42)
    plt.figure(figsize=(9,6))
    plt.scatter(sample["pm2_5"], sample["hospital_admissions"], alpha=0.25)
    coef = np.polyfit(sample["pm2_5"], sample["hospital_admissions"], 1)
    x = np.linspace(sample["pm2_5"].min(), sample["pm2_5"].max(), 100)
    plt.plot(x, coef[0] * x + coef[1])
    plt.title("PM2.5 vs Hospital Admissions")
    plt.xlabel("PM2.5")
    plt.ylabel("Hospital Admissions")
    plt.tight_layout()
    plt.savefig(OUTPUT_DIR / "pm25_vs_hospital_admissions.png", dpi=160)
    plt.close()

if __name__ == "__main__":
    df = load_and_prepare()
    quality_report(df)
    city_summary = create_summaries(df)
    create_charts(df, city_summary)

    print("\nCorrelation with hospital admissions:")
    print(
        df.select_dtypes("number")
          .corr()["hospital_admissions"]
          .sort_values(ascending=False)
    )
