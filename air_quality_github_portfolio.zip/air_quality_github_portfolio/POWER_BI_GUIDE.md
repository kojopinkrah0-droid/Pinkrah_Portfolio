# Power BI Dashboard Build Guide

## Project title
**Air Quality & Public Health Impact Dashboard**

## Recommended dashboard pages

### Page 1 — Executive Overview
Use:
- KPI Card: Average AQI
- KPI Card: Average PM2.5
- KPI Card: Total Hospital Admissions
- KPI Card: Average Hospital Capacity
- Horizontal bar chart: Average AQI by City
- Column chart: Average Hospital Admissions by City
- Donut chart: Records by Population Density
- Slicers: City, AQI Category, Population Density, Year

### Page 2 — Pollution & Health Relationship
Use:
- Scatter plot: PM2.5 vs Hospital Admissions
  - X-axis: pm2_5
  - Y-axis: hospital_admissions
  - Legend: city
  - Tooltips: aqi, pm10, no2, o3
- Column chart: Average Hospital Admissions by AQI Category
- Line chart: Average PM2.5 by Month
- Matrix: City × pollutant averages
- KPI: Correlation insight (describe in a text card: PM2.5 has the strongest observed relationship)

### Page 3 — City & Capacity Analysis
Use:
- Bar chart: Total Admissions by City
- Bar chart: Average Capacity Utilization % by City
- Scatter plot: Hospital Capacity vs Hospital Admissions
- Table: City, Avg AQI, Avg PM2.5, Avg Admissions, Avg Capacity, Utilization %

## Power Query transformations
1. Get Data > Text/CSV.
2. Promote headers if required.
3. Set data types:
   - city: Text
   - date: Date
   - aqi: Whole Number
   - pm2_5, pm10, no2, o3, temperature: Decimal Number
   - humidity, hospital_admissions, hospital_capacity: Whole Number
   - population_density: Text
4. Check nulls and errors.
5. Remove duplicate rows (this file currently has none).
6. Add Date.Year, Date.Month and Date.MonthName columns if preferred in Power Query.
7. Close & Apply.

## Recommended DAX measures

```DAX
Total Admissions =
SUM('AirQuality'[hospital_admissions])

Average Admissions =
AVERAGE('AirQuality'[hospital_admissions])

Average AQI =
AVERAGE('AirQuality'[aqi])

Average PM2.5 =
AVERAGE('AirQuality'[pm2_5])

Average PM10 =
AVERAGE('AirQuality'[pm10])

Average NO2 =
AVERAGE('AirQuality'[no2])

Average O3 =
AVERAGE('AirQuality'[o3])

Average Hospital Capacity =
AVERAGE('AirQuality'[hospital_capacity])

Capacity Utilization % =
DIVIDE(
    SUM('AirQuality'[hospital_admissions]),
    SUM('AirQuality'[hospital_capacity]),
    0
) * 100

Record Count =
COUNTROWS('AirQuality')

Hazardous Days =
CALCULATE(
    COUNTROWS('AirQuality'),
    'AirQuality'[aqi] > 300
)

Hazardous Day % =
DIVIDE([Hazardous Days], [Record Count], 0)
```

## Calculated column for AQI category

```DAX
AQI Category =
SWITCH(
    TRUE(),
    'AirQuality'[aqi] <= 50, "Good",
    'AirQuality'[aqi] <= 100, "Moderate",
    'AirQuality'[aqi] <= 150, "Unhealthy for Sensitive Groups",
    'AirQuality'[aqi] <= 200, "Unhealthy",
    'AirQuality'[aqi] <= 300, "Very Unhealthy",
    "Hazardous"
)
```

## Portfolio storytelling
Your dashboard should answer:
1. Which cities have the highest average air-pollution burden?
2. Which pollutants show the strongest relationship with hospital admissions?
3. Do hospital admissions rise as PM2.5 increases?
4. How does hospital capacity compare with demand?
5. How do pollution and admissions differ across population-density groups?

## Important data note
The date column extends from 2020 to 2262. This is unusual for a real-world observational health dataset. Mention this clearly in your GitHub README and avoid presenting the time span as verified historical evidence unless you know the source and generation method.
